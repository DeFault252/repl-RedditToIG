import os
import requests
import random
import asyncio
import logging
import json
import socket
import asyncpraw
import hashlib
from instagrapi import Client
from PIL import Image
import time
import subprocess
import ssl
import certifi
import urllib.parse
from moviepy.editor import VideoFileClip
from pathlib import Path
import sys
from instagrapi import Client
from instagrapi.types import Media
from functools import wraps
import re

def patch_instagram_client():
    """Comprehensive fix for Instagram API changes"""
    # 1. Patch Media class initialization
    original_media_init = Media.__init__

    def new_media_init(self, *args, **kwargs):
        # Fix missing scans_profile in candidates
        if 'image_versions2' in kwargs:
            candidates = kwargs['image_versions2'].get('candidates', [])
            for candidate in candidates:
                candidate.setdefault('scans_profile', 'ig_advanced')
        original_media_init(self, *args, **kwargs)

    Media.__init__ = new_media_init

    # 2. Patch client response handling
    if hasattr(Client, '_request'):
        original_request = Client._request

        @wraps(original_request)
        def patched_request(self, *args, **kwargs):
            try:
                response = original_request(self, *args, **kwargs)
                # Modify response before validation
                if response and 'media' in response:
                    media_data = response['media']
                    if 'image_versions2' in media_data:
                        candidates = media_data['image_versions2'].get('candidates', [])
                        for candidate in candidates:
                            if 'scans_profile' not in candidate:
                                candidate['scans_profile'] = 'ig_advanced'
                return response
            except Exception as e:
                logging.error(f"Request patching failed: {e}")
                raise

        Client._request = patched_request

# Apply the patch immediately
patch_instagram_client()


ssl_context = ssl.create_default_context(cafile=certifi.where())


# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Load secrets from environment variables
INSTAGRAM_USERNAME = os.getenv("INSTAGRAM_USERNAME")
INSTAGRAM_PASSWORD = os.getenv("INSTAGRAM_PASSWORD")
INSTAGRAM_PROXIES = os.getenv("INSTAGRAM_PROXIES", "").split(",")
REDDIT_CLIENT_ID = os.getenv("REDDIT_CLIENT_ID")
REDDIT_CLIENT_SECRET = os.getenv("REDDIT_CLIENT_SECRET")
REDDIT_USERNAME = os.getenv("REDDIT_USERNAME")
REDDIT_PASSWORD = os.getenv("REDDIT_PASSWORD")
REDDIT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
DRY_RUN = os.getenv("DRY_RUN", "true").lower() == "true"
ROYALTY_FREE_MUSIC = {
    "https://www.myinstants.com/media/sounds/let-me-know.mp3","https://www.myinstants.com/media/sounds/outro-song-xenogenesis.mp3","https://www.myinstants.com/media/sounds/freddy-beatbox.mp3","https://www.myinstants.com/media/sounds/smurfcat-we-live-we-love-we-lie.mp3"
}

# Global variables
reddit = None
bot = None
proxy_index = 0

# Session management for Instagram login
INSTAGRAM_SESSION_FILE = "session.json"

# Path to your predefined second image
SECOND_IMAGE_PATH = "meme.jpg"  # Update with your actual file path
PROCESSED_SECOND_IMAGE = "meme_processed.jpg"  # Resized version


def get_next_proxy():
    global proxy_index
    if INSTAGRAM_PROXIES and INSTAGRAM_PROXIES[0]:
        proxy = INSTAGRAM_PROXIES[proxy_index % len(INSTAGRAM_PROXIES)]
        proxy_index += 1
        return proxy
    return None

# Store downloaded files using hashes
DOWNLOADED_HASHES_FILE = "downloaded_hashes.json"
if os.path.exists(DOWNLOADED_HASHES_FILE) and os.stat(DOWNLOADED_HASHES_FILE).st_size > 0:
    with open(DOWNLOADED_HASHES_FILE, "r") as f:
        downloaded_hashes = json.load(f)
else:
    downloaded_hashes = []

def compute_file_hash(file_path):
    hasher = hashlib.md5()
    with open(file_path, "rb") as f:
        hasher.update(f.read())
    return hasher.hexdigest()

def save_downloaded_hash(file_hash):
    downloaded_hashes.append(file_hash)
    with open(DOWNLOADED_HASHES_FILE, "w") as f:
        json.dump(downloaded_hashes, f)

async def authenticate_reddit():
    global reddit
    try:
        # Check if the Reddit client is already authenticated
        if reddit:
            user = await reddit.user.me()
            if user:
                logging.info(f"Already authenticated as {user.name}")
                return  # Skip authentication if already logged in

        logging.info("Authenticating with Reddit API...")
        reddit = asyncpraw.Reddit(
            client_id=REDDIT_CLIENT_ID,
            client_secret=REDDIT_CLIENT_SECRET,
            user_agent=REDDIT_USER_AGENT,
            username=REDDIT_USERNAME,
            password=REDDIT_PASSWORD
        )
        user = await reddit.user.me()
        if user:
            logging.info(f"Reddit authentication successful. Logged in as {user.name}")
        else:
            logging.error("Reddit authentication failed: user object is None")
            reddit = None
    except Exception as e:
        logging.error(f"Reddit authentication failed: {e}")
        reddit = None

# Define subreddits to scrape
SUBREDDITS = ["funny","MemeVideos","memes","dankmemes","meme","HistoryMemes","ComedyCemetery"]
UPLOADED_POSTS_FILE = "uploaded_posts.json"

# Load previously uploaded posts
if os.path.exists(UPLOADED_POSTS_FILE) and os.stat(UPLOADED_POSTS_FILE).st_size > 0:
    with open(UPLOADED_POSTS_FILE, "r") as f:
        uploaded_posts = json.load(f)
else:
    uploaded_posts = []

def save_uploaded_post(post_id):
    uploaded_posts.append(post_id)
    with open(UPLOADED_POSTS_FILE, "w") as f:
        json.dump(uploaded_posts, f)

def get_reddit_video_urls(post):
    try:
        if post.is_video:
            media = post.media['reddit_video']
            video_url = media['fallback_url']

            # First try: Official audio URL
            audio_url = media.get('audio_url', None)

            # Second try: DASH audio manifest
            if not audio_url and 'dash_url' in media:
                dash_url = media['dash_url']
                response = requests.get(dash_url)
                if response.status_code == 200:
                    # Parse DASH manifest for audio
                    audio_match = re.search(r'<AudioChannelConfiguration.*?<BaseURL>(.*?)<', response.text)
                    if audio_match:
                        audio_url = audio_match.group(1)

            # Third try: Construct audio URL from video URL
            if not audio_url and "DASH_" in video_url:
                base_url = video_url.split('?')[0].rsplit('/', 1)[0]
                audio_url = f"{base_url}/DASH_AUDIO_128.mp4"

            return video_url, audio_url
    except Exception as e:
        logging.error(f"Video URL error: {e}")
    return None, None

def random_delay():
    time.sleep(random.uniform(5, 15))

def download_media(url, file_path):
    for attempt in range(3):
        try:
            response = requests.get(url, stream=True, headers={"User-Agent": REDDIT_USER_AGENT})
            if response.status_code == 200:
                with open(file_path, "wb") as f:
                    for chunk in response.iter_content(1024):
                        f.write(chunk)
                return True
        except Exception as e:
            logging.error(f"Failed to download media (Attempt {attempt+1}): {e}")
        time.sleep(2)
    return False
    
def verify_audio_stream(file_path):
    """Ensure audio stream exists in file"""
    try:
        cmd = ["ffprobe", "-i", file_path, "-show_streams", "-select_streams", "a"]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10)
        return b'codec_type=audio' in result.stdout
    except Exception as e:
        logging.error(f"Audio verification failed: {e}")
        return False
  
def merge_audio_video(video_path, audio_path, output_path):
    try:
        cmd = [
            "ffmpeg",
            "-i", video_path,
            "-i", audio_path,
            "-c:v", "copy",
            "-c:a", "aac",
            "-map", "0:v:0",
            "-map", "1:a:0",
            "-shortest",  # Use duration of the shortest stream
            output_path
        ]
        subprocess.run(cmd, check=True)
        return True
    except Exception as e:
        logging.error(f"Failed to merge audio and video: {e}")
        return False

def add_background_music(video_path, output_path):
    try:
        # Download music
        music_url = random.choice(list(ROYALTY_FREE_MUSIC))
        music_path = "background_music.mp3"
        if not download_media(music_url, music_path):
            return False

        # Get video duration
        clip = VideoFileClip(video_path)
        video_duration = clip.duration
        clip.close()

        # NEW: Check if video has audio
        cmd_check_audio = [
            "ffprobe", "-i", video_path,
            "-show_streams", "-select_streams", "a",
            "-loglevel", "error"
        ]
        result = subprocess.run(
            cmd_check_audio,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        has_audio = bool(result.stdout)

        # Build different commands based on audio presence
        if has_audio:
            # Mix existing audio with background music
            cmd = [
                "ffmpeg", "-i", video_path, "-i", music_path,
                "-filter_complex",
                f"[1:a]volume=0.3,aloop=loop=-1:size=2e+9[bg];"
                f"[bg]atrim=end={video_duration}[bg_trimmed];"
                f"[bg_trimmed]apad=whole_dur={video_duration}[bg_padded];"
                f"[0:a][bg_padded]amix=inputs=2:duration=longest[aout]",
                "-c:v", "copy", "-map", "0:v", "-map", "[aout]",
                "-shortest", output_path
            ]
        else:
            # For silent videos: use music as sole audio
            cmd = [
                "ffmpeg", "-i", video_path, "-i", music_path,
                "-filter_complex",
                f"[1:a]volume=0.3,aloop=loop=-1:size=2e+9[bg];"
                f"[bg]atrim=end={video_duration}[bg_trimmed];"
                f"[bg_trimmed]apad=whole_dur={video_duration}[aout]",
                "-c:v", "copy", "-map", "0:v", "-map", "[aout]",
                "-shortest", output_path
            ]

        subprocess.run(cmd, check=True)
        os.remove(music_path)
        return True

    except Exception as e:
        logging.error(f"Failed to add background music: {e}")
        return False

def build_ffmpeg_command(input_file, output_file, has_audio=True):
            cmd = [
                "ffmpeg", "-i", input_file,
                "-vf", "scale='min(1080,iw)':'min(1920,ih)':force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2",
                "-c:v", "libx264",
                "-preset", "fast",
                "-crf", "23",
                "-movflags", "faststart",
                "-t", "59", "-r", "24"
            ]

            if not has_audio:
                # For GIFs or videos without audio, omit audio settings
                cmd += ["-an"]
            else:
                cmd += ["-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2"]

            cmd.append(output_file)
            return cmd

def convert_media(file_path, file_extension):
    output_path = "converted.mp4" if file_extension in ["gif", "mp4"] else "converted.jpg"
    try:
        if file_extension == "gif":
            # For GIF, no need for audio settings
            temp_mp4 = "temp_video.mp4"
            cmd = build_ffmpeg_command(file_path, temp_mp4, has_audio=False)
            subprocess.run(cmd, check=True)
            os.rename(temp_mp4, output_path)

        elif file_extension == "mp4":
            # Check if the video has audio
            result = subprocess.run(
                ["ffprobe", "-i", file_path, "-show_streams", "-select_streams", "a", "-loglevel", "error"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            has_audio = bool(result.stdout)
            temp_mp4 = "temp_video.mp4"
            cmd = build_ffmpeg_command(file_path, temp_mp4, has_audio)
            subprocess.run(cmd, check=True)
            os.rename(temp_mp4, output_path)

        elif file_extension in ["jpg", "jpeg", "png"]:
            # Image processing logic remains the same
            img = Image.open(file_path)
            img = img.resize((1080, 1080))
            img.save(output_path)

        return output_path
    except Exception as e:
        logging.error(f"Failed to convert media: {e}")
        return None


def get_fun_fact_from_api():
    try:
        facts = []
        for _ in range(10):
            response = requests.get("https://uselessfacts.jsph.pl/random.json?language=en")
            if response.status_code == 200:
                fact_data = response.json()
                fact = fact_data.get("text", "Here's a random fun fact!")
                facts.append(fact)
        return facts
    except Exception as e:
        logging.error(f"Failed to fetch fun facts: {e}")
        return []

def is_valid_reel(video_path):
    try:
        clip = VideoFileClip(video_path)
        duration = clip.duration  # seconds
        width, height = clip.size
        aspect_ratio = height / width

        # Check conditions for a valid reel
        if duration > 60:
            print("❌ Video is longer than 60 seconds.")
            return False
        if aspect_ratio < 1.2:  # Less than 6:5 ratio
            print("❌ Video is not vertical enough.")
            return False
        if height < 720:
            print("❌ Video resolution is too low.")
            return False

        return True
    except Exception as e:
        print(f"⚠️ Error checking video: {e}")
        return False


def auto_fix_video_for_reel(file_path):
    """
    Tries to fix videos that are almost meeting Instagram's reel criteria
    (aspect ratio, duration, resolution), otherwise uploads as regular video.
    """
    try:
        clip = VideoFileClip(file_path)
        duration = clip.duration
        width, height = clip.size
        aspect_ratio = height / width

        fixed_video_path = None

        # Only fix video if it almost meets the requirements
        if aspect_ratio < 1.2 and aspect_ratio >= 1.15:  # Almost vertical enough
            new_height = int(width * 1.2)
            clip = clip.resize(height=new_height)

        # Fix duration if slightly over 60 seconds (e.g., between 61-65 seconds)
        if 60 < duration <= 65:
            clip = clip.subclip(0, 60)

        # Fix resolution if slightly lower than 720px height (e.g., between 640px-719px)
        if clip.size[1] < 720:
            clip = clip.resize(height=720)

        # After adjustments, check if we modified the video in any way
        if aspect_ratio < 1.2 or 60 < duration <= 65 or clip.size[1] < 720:
            fixed_video_path = "fixed_reel.mp4"
            clip.write_videofile(fixed_video_path, codec="libx264")
            return fixed_video_path

        # If no adjustments needed, return None
        return None
    except Exception as e:
        print(f"⚠️ Error fixing video: {e}")
        return None


def load_session():
    """
    Load session from the session file if it exists.
    """
    cl = Client()
    if os.path.exists(INSTAGRAM_SESSION_FILE):
        try:
            cl.load_settings(Path(INSTAGRAM_SESSION_FILE))
            logging.info("Session loaded from file.")
        except Exception as e:
            logging.error(f"Failed to load session: {e}")
            cl = None
    else:
        logging.info("No session file found. Starting fresh.")
    return cl


def save_session(cl):
    """
    Save the current session to a session file.
    """
    try:
        cl.dump_settings(Path(INSTAGRAM_SESSION_FILE))
        logging.info("Session saved to file.")
    except Exception as e:
        logging.error(f"Failed to save session: {e}")

def resize_image(image_path, output_path, size=(1080, 1080)):
    """Resize image to Instagram-friendly dimensions"""
    try:
        img = Image.open(image_path)
        img = img.resize(size, Image.Resampling.LANCZOS)
        img.save(output_path)
        return True
    except Exception as e:
        logging.error(f"Failed to resize image: {e}")
        return False

def post_to_instagram(media_paths, caption, is_video=False):
    if DRY_RUN:
        logging.info(f"[DRY RUN] Would upload media with caption:\n{caption}")
        return

    cl = load_session()
    if not cl:
        logging.error("No valid Instagram session found.")
        return

    try:
        # Try login if session is not active or expired
        try:
            cl.get_timeline_feed()  # Test if session is valid
            logging.info("Already logged in.")
        except Exception:
            logging.info("Logging into Instagram...")
            cl.login(INSTAGRAM_USERNAME, INSTAGRAM_PASSWORD)
            save_session(cl)  # Save the session after successful login
        else:
            logging.info("Already logged in.")

        # Handle different media types
        if is_video:
            # Video posts (single video only)
            if is_valid_reel(media_paths[0]):
                logging.info("Video meets Reel criteria. Uploading as Reel.")
                cl.video_upload(media_paths[0], caption)
            else:
                logging.warning("Video doesn't meet Reel criteria. Uploading as a regular video.")
                cl.video_upload(media_paths[0], caption)
        else:
            # Image posts (could be single or carousel)
            if len(media_paths) > 1:
                logging.info(f"Uploading carousel with {len(media_paths)} images")
                cl.album_upload(media_paths, caption)
            else:
                logging.info("Uploading single image")
                cl.photo_upload(media_paths[0], caption)

    except Exception as e:
        logging.error(f"❌ Upload failed: {e}")
        if "login_required" in str(e):
            logging.warning("🔁 Retrying after fresh login...")
            try:
                cl.login(INSTAGRAM_USERNAME, INSTAGRAM_PASSWORD)
                save_session(cl)  # Save session after re-login
                if is_video:
                    if is_valid_reel(media_paths[0]):
                        logging.info("Video meets Reel criteria. Uploading as Reel.")
                        cl.video_upload(media_paths[0], caption)
                    else:
                        logging.warning("Video doesn't meet Reel criteria. Uploading as a regular video.")
                        cl.video_upload(media_paths[0], caption)
                else:
                    if len(media_paths) > 1:
                        cl.album_upload(media_paths, caption)
                    else:
                        cl.photo_upload(media_paths[0], caption)
            except Exception as e:
                logging.error(f"Second upload attempt failed: {e}")

# Function to load the counter from a file (so it persists between script restarts)
def load_upload_counter():
    if os.path.exists("upload_counter.json"):
        with open("upload_counter.json", "r") as f:
            return json.load(f)
    return 1  # Default starting value

UPLOAD_COUNTER = load_upload_counter()

# Function to save the updated counter to a file
def save_upload_counter(counter):
    with open("upload_counter.json", "w") as f:
        json.dump(counter, f)

def video_has_audio(video_path):
    """Robust check for audio streams"""
    try:
        cmd = [
            "ffprobe", "-i", video_path,
            "-show_streams", "-select_streams", "a",
            "-loglevel", "error"
        ]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        # Look for audio stream indicators in output
        return b'codec_type=audio' in result.stdout
    except Exception as e:
        logging.error(f"Audio check failed: {e}")
        return False

async def scrape_and_post():
    global UPLOAD_COUNTER, reddit
    await authenticate_reddit()
    if reddit is None:
        return
    try:
        subreddit = await reddit.subreddit(random.choice(SUBREDDITS))
        async for post in subreddit.hot(limit=15):
            if post.id in uploaded_posts:
                continue
            if post.over_18:
                logging.info(f"Skipping NSFW post: {post.title}")
                continue

            # Get media URLs
            video_url, audio_url = get_reddit_video_urls(post)
            file_extension = None
            file_path = None
            temp_files = []  # Track temporary files for cleanup

            if video_url:  # Reddit video
                # Download video
                video_path = "video.mp4"
                if download_media(video_url, video_path):
                    temp_files.append(video_path)

                    # Download audio if available
                    if audio_url:
                        audio_path = "audio.mp3"
                        if download_media(audio_url, audio_path):
                            merged_path = "merged.mp4"
                            if merge_audio_video(video_path, audio_path, merged_path):
                                file_path = merged_path
                                file_extension = "mp4"
                                temp_files.extend([audio_path, merged_path])
                            else:
                                file_path = video_path  # Fallback to video without audio
                        else:
                            file_path = video_path  # Fallback to video without audio
                    else:
                        file_path = video_path  # Video without audio
                else:
                    continue
            else:  # External media
                media_url = post.url
                file_extension = urllib.parse.urlparse(media_url).path.split(".")[-1].split("?")[0]
                file_path = f"downloaded.{file_extension}"
                if download_media(media_url, file_path):
                    temp_files.append(file_path)
                else:
                    continue

            # Process media
            is_video = file_extension in ["mp4", "gif"] if file_extension else True
            converted_path = convert_media(file_path, file_extension if file_extension else "mp4")

            # NEW: Prepare media paths for upload
            media_paths = []

            if is_video:
                # For videos, just use the converted path
                media_paths.append(converted_path)

                # Check if video has audio
                if not video_has_audio(converted_path):
                    logging.info("Adding background music to silent video")
                    music_path = "with_music.mp4"
                    if add_background_music(converted_path, music_path):
                        media_paths = [music_path]  # Replace with new version
                        temp_files.append(converted_path)  # Mark old for cleanup
            else:
                # For images: create carousel
                media_paths.append(converted_path)

                # Process and add second image
                if os.path.exists(SECOND_IMAGE_PATH):
                    # Resize second image to Instagram dimensions
                    if resize_image(SECOND_IMAGE_PATH, PROCESSED_SECOND_IMAGE):
                        media_paths.append(PROCESSED_SECOND_IMAGE)
                        logging.info("Added second image for carousel")
                    else:
                        logging.warning("Failed to resize second image")
                else:
                    logging.warning(f"Second image not found at {SECOND_IMAGE_PATH}")

            fun_facts = get_fun_fact_from_api()

            # Improved formatting for the fun facts list with clean numbering
            facts_string = "\n".join([f"{i+1}. **Fact {i+1}**: {fact}" for i, fact in enumerate(fun_facts)])

            caption = f"""
            📢 {post.title}

            Mined meme #️⃣{UPLOAD_COUNTER}

            Credits📃: u/{post.author} from r/{post.subreddit}

            Here are some fun facts for you! 😂:

            {facts_string}

            #meme #shitpost #joke #memes #interesting #learn #knowledge #love #photography #beautiful #follow #cute #instalike  #lifestyle #anime #gaming #bestoftheday #tagsforlikes #music #friends #memespage #humor #comedy #reddit #memes #funny #memesdaily
            """

            # For videos: try to fix if needed
            if is_video:
                fixed_path = auto_fix_video_for_reel(media_paths[0])
                if fixed_path:
                    media_paths[0] = fixed_path

            post_to_instagram(media_paths, caption, is_video)
            save_uploaded_post(post.id)

            # Increment upload counter after successful upload
            UPLOAD_COUNTER += 1
            save_upload_counter(UPLOAD_COUNTER)

            # Cleanup
            if not DRY_RUN:
                # Delete all temporary files
                for path in temp_files:
                    if os.path.exists(path):
                        os.remove(path)
                # Delete processed files except the second image (we want to keep it)
                for path in media_paths:
                    if path != PROCESSED_SECOND_IMAGE and os.path.exists(path):
                        os.remove(path)
            else:
                logging.info(f"[DRY RUN] Would delete files: {temp_files}, {media_paths}")
            break

    finally:
        await reddit.close()
        reddit = None


if __name__ == "__main__":
    # Preprocess second image on startup
    if os.path.exists(SECOND_IMAGE_PATH):
        logging.info("Preprocessing second image...")
        if resize_image(SECOND_IMAGE_PATH, PROCESSED_SECOND_IMAGE):
            logging.info(f"Resized second image saved to {PROCESSED_SECOND_IMAGE}")
        else:
            logging.error("Failed to resize second image")
    else:
        logging.warning(f"Second image not found at {SECOND_IMAGE_PATH}")

    while True:
        asyncio.run(scrape_and_post())
        time.sleep(600)